# 附录I-术语表

* ADT(Algebraic Data Type:代数数据类型):
* ARC(Atomic Reference Counting:原子引用计数):
* associated function(关联函数):
* associated type(关联类型): Trait 里面可以有关联类型
* AST(Abstract Syntax Tree:抽象语法树):
* benchmark(基准测试):
* bitwise copy:
* borrow(借用):
* bounds(约束):
* box:
* byte string():
* cargo:
* cast:
* channel:
* coercion:
* constructor(构造器):
* consumer:
* copy:
* crate:
* dangling pointer:
* deref(解引用):
* derive:
* designator(指示符):
* destructor():
* destructure(析构):
* diverging function(发散函数):
* drop:
* DST(Dynamically Sized Type):
* dynamic dispatch(动态分发):
* enum():
* feature gate(特性开关): nightly 版本中有特性开关可以启用一些实验性质的特性
* FFI(Foreign Function Interface:外部函数接口):
* guard:
* hygiene:
* inline function(内联函数):
* item:
* iterator(迭代器):
* iterator adaptor(迭代器适配器):
* lifetime(生命周期):
* lifetime elision:
* literal string():
* macro by example:
* memberwise copy:
* module(模块)
* move:
* option:
* ownership(所有权):
* panic(崩溃):
* phantom type:
* primitive type(基本类型): 整型、浮点、布尔等基本类型
* procedural macro:
* RAII():
* raw string:
* raw pointer:
* RC(Reference Counting:引用计数)
* result:
* shadowing:
* static dispatch(静态分发):
* slice(切片): 某种数据类型的视图，例如 string, vector
* statement(): 与 expression 相区别
* trait:
* trait object:
* tuple(元组):
* UFCS(Universal Function Call Syntax)
* unit():
* unwind:
* unwrap():
* wrap:
