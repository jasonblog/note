#include "test.h"

int main() {
    xyz = 100;
    foo();
    foo();
    foo2();
    foo2();

    return 0;
}
