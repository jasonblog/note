function UnitsCompute() {
    	var w = document.getElementById("sel").value;
	document.getElementById("result").innerHTML = w*10000; 	
}
