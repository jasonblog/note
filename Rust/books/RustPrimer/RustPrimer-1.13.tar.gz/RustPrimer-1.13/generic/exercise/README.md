README
=======

`cargo run`
