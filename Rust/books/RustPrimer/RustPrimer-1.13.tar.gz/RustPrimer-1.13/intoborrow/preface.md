# 类型系统中的几个常见 trait

本章讲解 Rust 类型系统中的几个常见 trait。有 `Into, From, AsRef, AsMut, Borrow, BorrowMut, ToOwned, Deref, Cow`。


