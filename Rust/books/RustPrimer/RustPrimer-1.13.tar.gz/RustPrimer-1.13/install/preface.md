# 安装Rust

本章讲解在三大平台 Linux, MacOS, Windows 上分别安装 Rust 的步骤。
