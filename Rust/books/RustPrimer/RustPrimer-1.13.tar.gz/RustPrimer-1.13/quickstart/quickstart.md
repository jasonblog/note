# 快速上手

本章的目的在于快速上手(Quickstart)，对Rust语言建立初步的印象。
前面的章节中，我们已经安装好了Rust，配置好了编辑器，相信你一定已经跃跃欲试了。
注意: 本章的一些概念只需要大概了解就行，后续的章节将会有详细的讲解，但是本章的例子请务必亲自手敲并运行一遍。

下面，让我们开始动手写Rust程序吧!

ps：本章原始章节由 ee0703 书写的。因为内容不太满意，由 [Naupio（N猫）](https://github.com/Naupio)重写了整个章节，并加入大量的内容。特别鸣谢 [photino](https://github.com/photino) 提供的 [rust-notes](https://github.com/photino/rust-notes) 。本章也有大量内容编辑自 [Naupio（N猫）](https://github.com/Naupio) 创作中的 Rust  新书的快速入门章节。
