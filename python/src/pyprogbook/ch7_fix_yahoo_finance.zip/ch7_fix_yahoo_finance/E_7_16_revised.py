#E_7_15: 上網路抓取股價資料
from pandas_datareader import data as pdr
import fix_yahoo_finance as yf
import pandas as pd
import datetime
#下載資料起始日與股票代號
yf.pdr_override() # <== that's all it takes :-)
start = datetime.datetime(2016,1,1)
end = datetime.datetime(2018,3,1)
stockid=('2303', '2330', '3008', '2498', '2311', '2409', '2357', '2317')
writer=pd.ExcelWriter('./file/stocprice_revised.xlsx')
print(type(stockid))
for i in range(0,len(stockid)):
    sid=stockid[i]+'.tw'   
    df = pdr.get_data_yahoo(sid, start, end)
    df.to_excel(writer,stockid[i])
writer.save()