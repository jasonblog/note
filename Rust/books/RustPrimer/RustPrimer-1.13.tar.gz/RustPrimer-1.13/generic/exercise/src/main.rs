mod problem1;

fn main() {
    problem1::demo("Cargo.toml");
    problem1::demo("");
}
