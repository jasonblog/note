#ifndef TEST_H
#define TEST_H

extern int xyz;
int foo();

#endif
